---
name: Bad Link
about: Create a report to help us improve old links
title: ''
labels: 'old link,unverified'
assignees: ''

---
<!--
 #
 # Copyright (C) 2004-2024 The Cacti Group
 #
-->
# Describe the link

Please describe what the old link was for use for and if possible what the new link should be.

## Old Link

[ OLD LINK ]

## New Link

[ NEW LINK ]

## Screenshots

If applicable, add screenshots to help explain your problem.

## Additional context

Add any other context about the problem here.
