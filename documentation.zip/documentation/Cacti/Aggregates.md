# Aggregate Graphs

This section will describe **Aggregate Graphs** in Cacti.

---

Copyright (c) 2004-2024 The Cacti Group
